# Proyecto2_Practica3_I2C
Manejo del I2C y serial en un PIC18F47K42
