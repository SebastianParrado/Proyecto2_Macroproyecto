/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef GIROSCOPIO_H
#define	GIROSCOPIO_H

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdio.h>
#include "mcc_generated_files/uart1.h"
#include "mcc_generated_files/delay.h"
#include "mcc_generated_files/i2c1_master.h"
#include "mcc_generated_files/drivers/i2c_simple_master.h"

void giro_init(i2c1_address_t giro_address, uint8_t giro_power_mang, uint8_t reg_zero);

#endif	/* GIROSCOPIO_H */

