/* Ruler 1         2         3         4         5         6         7        */

/*
 * maquina_de_estados.c
 *
 * Created: 17/10/2020 11:39:22 a. m.
 *  Author: sebas
 */

#include "maquina_de_estados.h"

// Convierte un dato entero sin signo a ASCII codificado en hexadecimal
void FSM_Int2Hex(uint8_t dato_uint, char *a_char, char *b_char)
{
    uint8_t temp=0;
    // Guardando el caracter menos significativo
    temp = dato_uint%16; // Modulo para obtener el valor en hexa
    if (temp >= 0 && temp < 10) // Si el valor esta entre 0 y 9
    {
        temp = temp + '0';
        *b_char = temp;
    }
    else
    {
        temp = temp + '7'; // Si el valor esta entre 10 y 15
        *b_char = temp;
    }
    dato_uint = dato_uint/16;

    // Guardando el caracter mas significativo
    temp = dato_uint%16; // Modulo para obtener el valor en hexa
    if (temp >= 0 && temp < 10) // Si el valor esta entre 0 y 9
    {
        temp = temp + '0';
        *a_char = temp;
    }
    else
    {
        temp = temp + '7'; // Si el valor esta entre 10 y 15
        *a_char = temp;
    }
}

// Convierte de ASCII codificado en hexadecimal a un entero sin signo de 8 bits
uint8_t FSM_Hex2Int(char a_char, char b_char)
{
	uint8_t temp = 0;
	// Conviertiendo el bit mas significativo
	if (a_char >= '0' && a_char <= '9')
	{
		temp = (a_char - '0')*16;
	}
	else
	{
		if (a_char >= 'A' && a_char <= 'F')
		{
			temp = (a_char - '7')*16;
		}
	}
	
	// Conviertiendo el bit menos significativo
	if (b_char >= '0' && b_char <= '9')
	{
		temp = (b_char - '0')+temp;
	}
	else
	{
		if (b_char >= 'A' && b_char <= 'F')
		{
			temp = (b_char - '7')+temp;
		}
	}
	return temp;
}

// Convertir 4 caracteres a decimal
uint16_t FSM_Vec2Short(char a_char, char b_char, char c_char, char d_char)
{
    uint16_t valor = 0;
    if((a_char >= '0') & (a_char <= '9'))
    {
        a_char = a_char - '0'; // tambien funciona con 48 en numero
        valor = 16*16*16*a_char;
    }
    if ((a_char >= 'A') & (a_char <= 'F'))
    {
        a_char = a_char - '7'; // a = a - 55
        // Si a = caracter A, entonces esta operacion entrega un 10
        valor = valor + (16*16*16*a_char);
    }

    if((b_char >= '0') & (b_char <= '9'))
    {
        b_char = b_char - '0'; // tambien funciona con 48 en numero
        valor = valor + (16*16*b_char);
    }
    if ((b_char >= 'A') & (b_char <= 'F'))
    {
        b_char = b_char - '7'; // a = a - 55
        // Si a = caracter A, entonces esta operacion entrega un 10
        valor = valor + (16*16*b_char);
    }

    if((c_char >= '0') & (c_char <= '9'))
    {
        c_char = c_char- '0'; // tambien funciona con 48 en numero
        valor = valor + (16*c_char);
    }
    if ((c_char >= 'A') & (c_char <= 'F'))
    {
        c_char = c_char - '7'; // a = a - 55
        // Si a = caracter A, entonces esta operacion entrega un 10
        valor = valor + (16*c_char);
    }

    if((d_char >= '0') & (d_char <= '9'))
    {
        d_char = d_char - '0'; // tambien funciona con 48 en numero
        valor = valor + (d_char);
    }
    if ((d_char >= 'A') & (d_char <= 'F'))
    {
        d_char = d_char - '7'; // a = a - 55
        // Si a = caracter A, entonces esta operacion entrega un 10
        valor = valor + (d_char);
    }
    return valor;

}

void FSM_Init_Estado(M_estados_T *m, eCola_T *f) 
{
    m->estado = ESTADO1;
    m->bandera_error = 0;
    m->bandera_exito = 0;
    m->bandera_inst1 = 0;
    m->bandera_inst2 = 0;
    m->bandera_inst3 = 0;
    m->bandera_inst4 = 0;
    
    m->bandera_cola = 0x00;
    
    m->vec_direccion[4] = "0000";
    m->vec_numero[3] = "000";
    m->bandera_leer_giro =  0;
    /**/
}

void FSM_Init_Apuntadores(M_estados_T *m, eCola_T *f)
{
    m->cola1 = f;
}

void FSM_maquina_de_estados(M_estados_T *m, DATOCOLA recepcion)
{
    switch(m->estado) {     
        //======================================================================
        case ESTADO1:
            if(recepcion == 'R') {
                m->estado = ESTADO2;
            }

            if(recepcion == 'W') {
                m->estado = ESTADO3;
            }
            
            if(recepcion == 'G') {
             m->estado = ESTADO8;
            }
            
            if ((recepcion != 'R')&&(recepcion != 'W')) {
              m->bandera_error = 1;
              m->estado = ESTADO1;
            }
        break;

        //======================================================================
        case ESTADO2:
            if(recepcion == 'B') {
                m->count_direcciones = 0; // Inicializa el contador
                m->estado = ESTADO4;
            }

            if(recepcion == 'S') {
                m->count_direcciones = 0; // Inicializa el contador
                m->count_numero = 0; // Inicializa el contador
                m->estado = ESTADO5;
            }

             if ((recepcion != 'B')&&(recepcion != 'S')) {
                m->bandera_error = 1;
                m->estado = ESTADO1;
            }
        break;

        //======================================================================
        case ESTADO3:
            if(recepcion == 'B') {
                m->count_direcciones = 0;
                m->count_numero = 0;
                m->estado = ESTADO6;
            }
           
            if(recepcion == 'S') {
                m->count_direcciones = 0;
                m->count_numero = 0;
                m->count_final = 0;
                m->estado = ESTADO7;
            }
             if ((recepcion != 'B')&&(recepcion != 'S')) {
                m->bandera_error = 1;
                m->estado = ESTADO1;
            }
        break;

        //======================================================================
        case ESTADO4: // Lectura de la direccion de 16 bit en HEX ASCII
            // Lectura de la direccion |R|B|ADD|\n| [0] [1] [2,3] [4]]
            // R B x x x x \n
            if (m->count_direcciones < 5) {
                if(m->count_direcciones < 4) {
                    m->bandera_cola = cola_add(m->cola1, recepcion);
                    //m->vec_direccion[m->count_direcciones] = recepcion;
                    m->estado = ESTADO4; // Vuelve al estado hasta guardar todos los caracteres
                }
                
                // Evalua el ultimo dato de la instruccion
                //if (m->count_direcciones >= 4 && recepcion == '\n') {
                if(m->count_direcciones >= 4 && m->bandera_cola == HUBO_FINLINEA){
                    m->bandera_inst1 = 1;	
                    m->estado = ESTADO1;      
                }
                
                //if (m->count_direcciones >= 4 && recepcion != '\n') {
                if(m->count_direcciones >= 4 && m->bandera_cola == NO_HUBOFINLINEA){
                    m->bandera_error = 1;
                    m->estado = ESTADO1;
                }
                m->count_direcciones = m->count_direcciones+1; 
            } // termino de guardar los datos en la cola
            else {
                m->estado = ESTADO1; 
            }
        break;
        
        //======================================================================
        /*
        case ESTADO5:
            // |R|S|(ADD)| , |(NUM)|\n| leo (num) datos desde la direccion (address)
            // R S x x x x , y y \n        
            if (m->count_direcciones < 5) {
                if(m->count_direcciones < 4) {
                    m->vec_direccion[m->count_direcciones] = recepcion;
                }
                
                // Evalua el ultimo dato de la instruccion 
                if (m->count_direcciones >= 4 && recepcion == ',') {
                    m->bandera_exito = 1; //recibi los 4 numeros de la direcci�n
                    m->bandera_error = 0;
                    // No va a ningun estado. Sigue evaluando los otros condicionales
                }

                if (m->count_direcciones >= 4 && recepcion != ',') {
                    m->bandera_error = 1;
                    m->estado = ESTADO1;
                }
                m->count_direcciones = m->count_direcciones+1; 
            } // termino de guardar los datos en el vector rxData
            
            if(m->bandera_exito == 1) {
                // Se usa 4 y no 3, porque la recepcion de la , aumenta el contador 
                if(m->count_numero < 4) {
                    if(m->count_numero < 3) {
                        m->vec_numero[m->count_numero] = recepcion;
                        m->estado = ESTADO5; // Vuelve al estado hasta guardar todos los caracteres
                    }
                    
                
                    if(m->count_numero >= 3 && recepcion == '\n' ) {
                        m->bandera_inst2 = 1;
                        m->bandera_exito = 0; // Se reinicia la bandera cuando ya ha tomado los datos
                        m->estado = ESTADO1;
                    }

                    if (m->count_numero >= 3 && recepcion != '\n') {
                        m->bandera_error = 1;
                        m->estado = ESTADO1;
                    }
                    m->count_numero = m->count_numero+1;
                }
            }
        break;

        
        //======================================================================
        case ESTADO6: // Lectura de la direccion de 16 bit en HEX ASCII
            // Lectura de la direccion |W|B|ADD| , |VAL|\n| [0] [1] [2,3] [4] [5] [6]
            
            // W B x x x x , y y \n        
            if (m->count_direcciones < 5) {
                if(m->count_direcciones < 4) {
                    m->vec_direccion[m->count_direcciones] = recepcion;
                }
                
                // Evalua el ultimo dato de la instruccion 
                if (m->count_direcciones >= 4 && recepcion == ',') {
                    m->bandera_exito = 1; //recibi los 4 numeros de la direcci�n
                    m->bandera_error = 0;
                    // No va a ningun estado. Sigue evaluando los otros condicionales
                }

                if (m->count_direcciones >= 4 && recepcion != ',') {
                    m->bandera_error = 1;
                    m->estado = ESTADO1;
                }
                m->count_direcciones = m->count_direcciones+1; 
            } // termino de guardar los datos en el vector rxData
            
            if(m->bandera_exito == 1) {
                // Se usa 4 y no 3, porque la recepcion de la , aumenta el contador 
                if(m->count_numero < 4) {
                    if(m->count_numero < 3) {
                        m->vec_numero[m->count_numero] = recepcion;
                        m->estado = ESTADO6; // Vuelve al estado hasta guardar todos los caracteres
                    }
                    
                
                    if(m->count_numero >= 3 && recepcion == '\n' ) {
                        m->bandera_inst3 = 1;
                        m->bandera_exito = 0; // Se reinicia la bandera cuando ya ha tomado los datos
                        m->estado = ESTADO1;
                    }

                    if (m->count_numero >= 3 && recepcion != '\n') {
                        m->bandera_error = 1;
                        m->estado = ESTADO1;
                    }
                    m->count_numero = m->count_numero+1;
                }
            }
        break;

        
        //======================================================================
        case ESTADO7:
            // |W|S|(ADD)| , |(NUM)| , |d0| , |d1| , | ... | , |dn|
            // W S x x x x , y y , z z, w w, \n        
            if (m->count_direcciones < 5) {
                if(m->count_direcciones < 4) {
                    m->vec_direccion[m->count_direcciones] = recepcion;
                }
                
                // Evalua el ultimo dato de la instruccion 
                if (m->count_direcciones >= 4 && recepcion == ',') {
                    m->bandera_exito = 1; //recibi los 4 numeros de la direcci�n
                    m->bandera_error = 0;
                    // No va a ningun estado. Sigue evaluando los otros condicionales
                }

                if (m->count_direcciones >= 4 && recepcion != ',') {
                    m->bandera_error = 1;
                    m->estado = ESTADO1;
                }
                m->count_direcciones = m->count_direcciones+1; 
            } 
            
            // Para saber cuantos numeros escribir
            if(m->bandera_exito == 1) {
                // Se usa 4 y no 3, porque la recepcion de la , aumenta el contador 
                if(m->count_numero < 4) {
                    if(m->count_numero < 3) {
                        m->vec_numero[m->count_numero] = recepcion;
                        m->estado = ESTADO7; // Vuelve al estado hasta guardar todos los caracteres
                    }
                    
                
                    if(m->count_numero >= 3 && recepcion == '.' ) {
                        m->bandera_exito = 0; // Se reinicia la bandera cuando ya ha tomado los datos
                        m->count_numero = 0; // Lo reinicia antes de saltar al otro estado
                        m->count_final = FSM_Hex2Int(m->vec_numero[1], m->vec_numero[2]);
                                                
                        m->estado = ESTADO8;
                    }

                    if (m->count_numero >= 3 && recepcion != '.') {
                        m->bandera_error = 1;
                        m->estado = ESTADO1;
                    }
                    m->count_numero = m->count_numero+1;
                }
            }
        break;
        */ 
        //======================================================================
        case ESTADO8:
            m->bandera_leer_giro = 1;        
            if(UART1_is_tx_ready()) {
                 UART1_Write('Y');
            }
            /*
            if(m->count_numero != m->count_final) {
                m->vec_numero[m->count_numero] = recepcion;
                if(recepcion == ',') {
                    // Ir guardando datos
                    m->estado = ESTADO8;
                }
                
                if(recepcion == '\n') {
                    m->bandera_exito = 1;
                    m->estado = ESTADO1;
                }
                if(recepcion != '\n' && ) {
                    m->bandera_exito = 1;
                    m->estado = ESTADO1;
                }
            }
            */ 
        //break;

        //======================================================================
        default:
            m->estado = ESTADO1;
            // Aqui nunca deberia llegar. Si llega por casualidad devuelve al
            // estado 1

    } /*switch */
} /* FSM */