/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef FSM_H
#define	FSM_H

#include <xc.h> // include processor files - each processor file is guarded.  

#include <stdio.h>
#include "mcc_generated_files/uart1.h"
#include "mcc_generated_files/delay.h"
#include "cola.h"


// Numeracion de estados
//#define ESTADO0 0
#define ESTADO1 1
#define ESTADO2 2
#define ESTADO3 3
#define ESTADO4 4
#define ESTADO5 5
#define ESTADO6 6
#define ESTADO7 7
#define ESTADO8 8


// Estructura para la maquina de estados
typedef struct M_estados_T M_estados_T;
struct M_estados_T
{
    int8_t estado;
    
    // Arreglos para guardar datos de la UART
    char vec_direccion[4];
    char vec_numero[3];
    /**/
    // Banderas_comunicacion
    bool bandera_exito;
    bool bandera_error;
    bool bandera_inst1;
    bool bandera_inst2;
    bool bandera_inst3;
    bool bandera_inst4;
    
    // Bandera de la cola
    char bandera_cola;
    // Apuntadores a Colas
    eCola_T *cola1;
    
    // Contadores para poder guardar los datos de la UART
    uint8_t count_direcciones;
    uint8_t count_numero;
    uint8_t count_final;
    
    bool bandera_leer_giro;
};

void FSM_Int2Hex(uint8_t dato_uint, char *a_char, char *b_char);

uint8_t FSM_Hex2Int(char a_char, char b_char);

uint16_t FSM_Vec2Short(char a_char, char b_char, char c_char, char d_char);

void FSM_Init_Estado(M_estados_T *m, eCola_T *f);

void FSM_Init_Apuntadores(M_estados_T *m, eCola_T *f);

void FSM_maquina_de_estados(M_estados_T *m, DATOCOLA recepcion);
//void FSM_maquina_de_estados(M_estados_T *m, DATOCOLA recepcion);

#endif	/* FSM_H */

