#include "temperatura.h"

void temp_initRegApuntador(temperatura_T *ptr)
{
    
} // temp_initRegApuntador
void temp_initConfig(temperatura_T *ptr)
{
    
} // temp_initConfig
void temp_initLectura(temperatura_T *ptr)
{
    
} // temp_initLectura